#Nicholas Chiarello
#Pong
#1/19/2017

#Welcome to my program, youll be reading this with my commentary
#Right now we are just importing parts we need, and some parts I thought I needed and kept in case I ever did need it
import os
import sys
import pygame, sys, time
from pygame.locals import *
from pygame.constants import *
from random import randint
#and these are variables that will be used later
#again just says wether the program goes again at the end
#The rest is highscores
again = True
wins = 0
lose = 0
games = 0
while again == True:
    #These are all similar to the examples and earlier things we worked on with minor changes, no explanation needed
    fpsClock = pygame.time.Clock()

    colourWhite = pygame.Color(255,255,255)
    colourBlack = pygame.Color(0,0,0)

    width = 1366
    height = 768
    gameStart = False

    pointLimit = 10
    twoP = True
    #Lets begin!
    print "Welcome to PONG"
    print "Enter a number to get started"
    while gameStart == False:
        print "[1] Start Game"
        print "[2] Settings"
        print "[3] Highscores"
        print "[4] Credits"
        print "[5] Help"
        print "[6] Quit"
        menuChoice = raw_input(">_")
        if menuChoice == "6": #Quits the game
            done = True
            gameStart = True
            print "\nThank you for playing!"
        elif menuChoice == "5": #This brings up useful information on the game and should be the first thing you access
            print "\nTo play on your own, use the W key to move the paddle up and the S key to move the paddle down."
            print "\nIf playing with a friend, the other player uses the ^ and v keys on the directional buttons.\n"
            print "\nWhen you start the game, it may start unfocused. Make sure all other programs are minimized, so that you may quickly and easily focus the game when it pops up.\n"
        elif menuChoice == "4": #Brings up the credits, no one ever looks at those
            print "\nProgrammer: Nicholas Chiarello"
            print "Art: Nicholas Chiarello"
            print "SFX: The Internet"
            print "Left Paddle: Jerry Richter"
            print "Right Paddle: Captain Pete"
            print "Ball: Tiny Tim\n"
        elif menuChoice == "3": #Displays the number of wins and losses you got in singleplayer mode this session only
            print "\nTotal games played this session: " + str(games)
            print "Number of Wins this session: " + str(wins)
            print "Number of Losses this session: " + str(lose) + "\n"


            
        elif menuChoice == "2": #Allows you to change the sound and the point limit (The default game is too long for some people). Should be the second place you look
            pointLimit = 11
            while int(pointLimit) <= 0 or int(pointLimit) >= 11:
                pointLimit = raw_input("Enter the amount of points needed to win (Up to a maximum of 10): ")
            print "You entered " + pointLimit + " points"
            sound = raw_input("Play with sound? y/n\n>_")
            if sound == "y":
                print "Sound is ON."
            elif sound == "n":
                print "Sound is OFF."
            else:
                print "Invalid input: Setting Unchanged - Sound defaults to ON"


        elif menuChoice == "1": #Starts the game, which is probably why it says so
            while gameStart == False:
                print "How many players (1-2)?"
                playerChoice = raw_input(">_") #Then you say wether you have friends or not
                if playerChoice == "1": #You have no friends
                    twoP = False
                    gameStart = True
                    break
                elif playerChoice == "2": #You have friends :)
                    twoP = True
                    gameStart = True
                    break
                else:
                    print "1-2 Players." #You can only have one friend/enemy
            print"\n\nGET TO " + str(pointLimit) + " POINTS TO WIN" #The game finally starts
        elif menuChoice == "420": #Easter egg if you think your funny
            print "Blaze it"
        elif menuChoice.lower() == "^^vv<><>BAstart": #Easter Egg if you think your smart
            print "YOUR WINNER"
        elif menuChoice.lower() == "konami": #Easter egg if your forgetful
            print "Up\Up\Down\Down\Left\Right\Left\Right\B\A\Start"
        elif menuChoice.lower() == "cheat code": #Easter egg if you are very unoriginal
            print "Cheat Code Unlocked"
        elif menuChoice == "911" or menuChoice == "9/11": #Easter egg if your very insensitive
            print "bush did it"
        else:
            print "Enter an available number please."

    pygame.init()
    #_+_+_+_+_+_+_+_+_+_+_+_+_+_RESTART FROM HERE_+_+_+_+_+_+_+_+_+_+_+_+_+_+_
    #This is a def because then I can restart the main game much easier
    def startPong(wins, lose, games):
        pygame.mixer.init(22050, -16,2,4096)

        sounds = (pygame.mixer.Sound("C:\Users\madeu\Desktop\Programs and Scripts\Python Programs\School Programs\PONG\paddleBeep"), pygame.mixer.Sound("C:\Users\madeu\Desktop\Programs and Scripts\Python Programs\School Programs\PONG\wallBoop"))
        done = False
        screen = pygame.display.set_mode((width,height), pygame.FULLSCREEN) #This is the screen that is displayed (which is the whole screen)

        pygame.display.set_caption ('PPOONNGG') #This is useless unless you change the dimensions of the window size to something other than fullscreen (Name inspired by Classic NES series of games)

        #These are all just coordinates I defined to make the creation of the numbers easier
        topLeft = (width/2-65, 50)
        topRight = (width/2-15, 50)
        middleLeft = (width/2-65, 100)
        middleRight = (width/2-15, 100)
        bottomLeft = (width/2-65, 150)
        bottomRight = (width/2-15, 150)
        twoTL = (width/2+15, 50)
        twoTR = (width/2+65, 50)
        twoML = (width/2+15, 100)
        twoMR = (width/2+65, 100)
        twoBL = (width/2+15, 150)
        twoBR = (width/2+65, 150)

        #The number of points the player has
        onePoints = 0
        twoPoints = 0

        #This is the display for the scoreboard, using coordinates from above. The 6 is intentionally like that, after I accidentaly made it backwards and found it funny
        pointsDisplay = [[topLeft, topRight, bottomRight, bottomLeft], [topRight, bottomRight], [topLeft, topRight, middleRight, middleLeft, bottomLeft, bottomRight], [topLeft, topRight, middleRight, middleLeft, middleRight, bottomRight, bottomLeft], [topLeft, middleLeft, middleRight, topRight, bottomRight], [topRight, topLeft, middleLeft, middleRight, bottomRight, bottomLeft], [topRight, bottomRight, bottomLeft, middleLeft, middleRight], [topLeft, topRight, bottomRight], [topLeft, topRight, middleRight, middleLeft, middleRight, bottomRight, bottomLeft], [bottomRight, topRight, topLeft, middleLeft, middleRight]] 
        ##               |__________________Zero____________________|  |_________One_________|  |_____________________________Two___________________________________|  |___________________________________Three________________________________________|  |__________________________Four_________________________|  |_______________________________Five________________________________|  |___________________________Six____________________________|  |__________Seven_______________|  |__________________________________Eight_________________________________________|  |_______________________Nine____________________________|
        displayTwo = [[twoTL, twoTR, twoBR, twoBL], [twoTR, twoBR], [twoTL, twoTR, twoMR, twoML, twoBL, twoBR], [twoTL, twoTR, twoMR, twoML, twoMR, twoBR, twoBL], [twoTL, twoML, twoMR, twoTR, twoBR], [twoTR, twoTL, twoML, twoMR, twoBR, twoBL], [twoTR, twoBR, twoBL, twoML, twoMR], [twoTL, twoTR, twoBR], [twoTL, twoTR, twoMR, twoML, twoMR, twoBR, twoBL], [twoBR, twoTR, twoTL, twoML, twoMR]]
        ##            |________ZERO______________|  |___ONE______|  |_____________________TWO________________|  |_______________________THREE___________________|  |_____________FOUR________________|  |____________________FIVE________________|  |______________SIX________________|  |______SEVEN________|  |___________________EIGHT_______________________|  |_______________NINE______________|

        #Ball Position and speed
        x = 320
        y = 240
        speed = 10
        #Paddle starting positions (Done so that if the screen dimensions are changed, it will stay relative to the middle of the screen)
        paddleOnePos = height/2-50
        paddleTwoPos = height/2-50
        #The direction the ball moves
        moveRight = True
        moveLeft = False
        moveDown = True
        moveUp = False

        #This is how the paddles move, using the event.get thing below
        oneUp = False
        oneDown = False
        twoUp = False
        twoDown = False
        #These are comments that the program says when the ball moves fast enough (You probably will never read them, but they are there
        heatup = False
        fire = False
        menu = True
        playWall = False

        while not done:
            #This is where the comments are printed
            if speed > 50 and heatup == False:
                print "Things are heating up now!"
                heatup = True
            if speed > 100 and fire == False:
                print "These players are on fire!"
                #This is what says if you are clicking Up, Down, W, or S. If the button is pushed down (KEYDOWN), a variable becomes True, and the paddle moves in the respective direction
                #and then stops once you lift your finger. It also reads the ESC key in the corner, so you can quit the game
            for event in pygame.event.get():
                if (event.type == KEYUP):
                    if event.key == K_UP:
                            twoUp = False
                    elif event.key == K_DOWN:
                            twoDown = False
                    if event.key == K_w:
                            oneUp = False
                    elif event.key == K_s:
                            oneDown = False
                elif (event.type == KEYDOWN):
                    if event.key == K_UP:
                            twoUp = True
                    elif event.key == K_DOWN:
                            twoDown = True
                    if event.key == K_w:
                            oneUp = True
                    elif event.key == K_s:
                            oneDown = True
                    if (event.key == K_ESCAPE):
                        done = True
            screen.fill(colourBlack)

            #Here, we draw the scoreboard, based on how many points you have
            if onePoints == 0:
                pygame.draw.lines(screen, colourWhite, True, pointsDisplay[0], 6)
            elif onePoints == 1:
                pygame.draw.lines(screen, colourWhite, False, pointsDisplay[1], 6)
            elif onePoints == 2:
                pygame.draw.lines(screen, colourWhite, False, pointsDisplay[2], 6)
            elif onePoints == 3:
                pygame.draw.lines(screen, colourWhite, False, pointsDisplay[3], 6)
            elif onePoints == 4:
                pygame.draw.lines(screen, colourWhite, False, pointsDisplay[4], 6)
            elif onePoints == 5:
                pygame.draw.lines(screen, colourWhite, False, pointsDisplay[5], 6)
            elif onePoints == 6:
                pygame.draw.lines(screen, colourWhite, False, pointsDisplay[6], 6)
            elif onePoints == 7:
                pygame.draw.lines(screen, colourWhite, False, pointsDisplay[7], 6)
            elif onePoints == 8:
                pygame.draw.lines(screen, colourWhite, True, pointsDisplay[8], 6)
            elif onePoints == 9:
                pygame.draw.lines(screen, colourWhite, False, pointsDisplay[9], 6)
            #This was a very easy, but very frustrating and boring part, I could have probably found a better way than this, but there were more important parts of the program to worry about
            if twoPoints == 0:
                pygame.draw.lines(screen, colourWhite, True, displayTwo[0], 6)
            elif twoPoints == 1:
                pygame.draw.lines(screen, colourWhite, False, displayTwo[1], 6)
            elif twoPoints == 2:
                pygame.draw.lines(screen, colourWhite, False, displayTwo[2], 6)
            elif twoPoints == 3:
                pygame.draw.lines(screen, colourWhite, False, displayTwo[3], 6)
            elif twoPoints == 4:
                pygame.draw.lines(screen, colourWhite, False, displayTwo[4], 6)
            elif twoPoints == 5:
                pygame.draw.lines(screen, colourWhite, False, displayTwo[5], 6)
            elif twoPoints == 6:
                pygame.draw.lines(screen, colourWhite, False, displayTwo[6], 6)
            elif twoPoints == 7:
                pygame.draw.lines(screen, colourWhite, False, displayTwo[7], 6)
            elif twoPoints == 8:
                pygame.draw.lines(screen, colourWhite, True, displayTwo[8], 6)
            elif twoPoints == 9:
                pygame.draw.lines(screen, colourWhite, False, displayTwo[9], 6)

            #This draws the paddles, ball, and dividing line into the game
            pygame.draw.lines(screen, colourWhite, False, ([width/2, 50], [width/2, height-50]), 2) #Divider
            pygame.draw.rect(screen, colourWhite, (x, y, 8, 8), 0) #Ball
            pygame.draw.rect(screen, colourWhite, (25, paddleOnePos, 20, 100), 0) #Paddle 1
            pygame.draw.rect(screen, colourWhite, (width-45, paddleTwoPos, 20, 100), 0) #Paddle 2

            pygame.display.update()
            fpsClock.tick(30)
            #If the ball goes behind the left side of the screen, you get a point, or two if the speed went high enough
            if x < 0:
                if speed > 49:
                    twoPoints += 2
                    print "2 points for Player Two, bringing him to " + str(twoPoints) + " point(s)"
                else:
                    twoPoints += 1
                    print "1 point for Player Two, bringing him to " + str(twoPoints) + " point(s)"
                #Then it resets the speed
                speed = 10
                heatup = False
                fire = False
                #The game freezes for a minute, to let the overwhelming defeat of your opponent sink into them
                pygame.time.delay(2500)
                #Then the ball goes back to a random part in the middle
                x = width/2
                y = randint(15,height-15)
                #And the paddle resets as well
                paddleOnePos = height/2-50
                paddleTwoPos = height/2-50
                #The ball will be served to Player 2
                moveRight = True
                moveLeft = False
                #Then you repeat all of the above, except reverse everything, because the ball went behind the RIGHT side this time. Player 1 gets the point(s), ball is served to 1
            elif x+4 > width:
                if speed > 49:
                    onePoints += 2
                    print "2 point for Player One, bringing him to " + str(onePoints) + " point(s)"
                else:
                    onePoints += 1
                    print "1 point for Player One, bringing him to " + str(onePoints) + " point(s)"
                speed = 10
                heatup = False
                fire = False
                
                pygame.time.delay(2500)
                x = width/2
                y = randint(15, height-15)
                paddleOnePos = height/2-50
                paddleTwoPos = height/2-50
                moveRight = False
                moveLeft = True
            elif y < 0:
                moveUp = False
                moveDown = True
                pygame.mixer.music.load("C:\PONG\wallBoop.wav")
                pygame.mixer.music.play()
                

            elif y+4 > height:
                moveUp = True
                moveDown = False
                pygame.mixer.music.load("C:\PONG\wallBoop.wav")
                pygame.mixer.music.play()



            #This is what lets the ball move
            if moveUp == True:
                y -= speed/2
            elif moveDown == True:
                y += speed/2
            if moveLeft == True:
                x -= speed
            elif moveRight == True:
                x += speed
            #And here, (if twoP is True), The second player controls the second paddle
            if twoP == True:
                if twoUp == True:
                    paddleTwoPos -= 12
                if twoDown == True:
                    paddleTwoPos += 12
                    #Unless it is actually false, in case they dont
                    #AI CODE v
            elif twoP == False:
                if y > (paddleTwoPos+50):
                    paddleTwoPos += 12
                if y < (paddleTwoPos+50):
                    paddleTwoPos-=12
                    #AI CODE ^
                #And this is where you control yours (with W and S)
            if oneUp == True:
                paddleOnePos -= 12
            if oneDown == True:
                paddleOnePos += 12
            #If the ball hits a paddle it...
            if x <= 45 and (y >= paddleOnePos and y <= paddleOnePos + 100) and lBounce == False:
                #It bounces off
                lBounce = True
                moveLeft = False
                moveRight = True
                #Goes faster
                speed += 2.5
                #And plays a sound
                pygame.mixer.music.load("C:\Users\madeu\Desktop\Programs and Scripts\Python Programs\School Programs\PONG\paddleBeep.wav")
                pygame.mixer.music.play()
                #Like above, this is commentary, and you may not read this while actually playing
                print "Speed is at " + str(speed)
            else:
                #This is to prevent the ball from bouncing multiple times off the same paddle in quick succesion
                lBounce = False

            #And this is the same as directly above but for the other paddle
            if x+4 >= width-45 and (y >= paddleTwoPos and y <= paddleTwoPos + 100) and rBounce == False:
                rBounce = True
                moveLeft = True
                moveRight = False
                speed += 2.5
                powerGet = 1
                pygame.mixer.music.load("C:\Users\madeu\Desktop\Programs and Scripts\Python Programs\School Programs\PONG\paddleBeep.wav")
                pygame.mixer.music.play()
                print "Speed is at " + str(speed)
                
            else:
                rBounce = False

            #If player one has enough points to win
            if onePoints == int(pointLimit):
                #Quit the game and say so
                pygame.quit()
                print "Player One Wins!"
                done = True
                #If you were facing a robot overlord and won, you will be rewarded by a badge (which is worthless)
                if twoP == False:
                    wins += 1
                    games += 1
                
            elif twoPoints == int(pointLimit):
                pygame.quit()
                print "Player Two Wins!"
                done = True
                #Otherwise if you lost, you will be jeered on the return trip by your comrades
                if twoP == False:
                    lose += 1
                    games += 1
            
    #This is a little disorienting
    #This is the first time that the game starts, everything above has not haappened yet, its only what is about to happen
    while not done:
        startPong(wins, lose, games)
    pygame.quit()
    #Do you want to play again?
    print 'Play again? y/n'
    print "Any input beyond y or n will be regarded as n"
    quitter = raw_input("")
    #Now the game stays as True and restarts the programs main menu
    if quitter == "y":
        again = True
    else:
        #And here is where you go after a joyful few hours of intense PONGivity
        print "Thank you for playing! Goodbye"
        again = False
    #fin~
    sys.exit(0)
